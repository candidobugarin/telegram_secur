package com.example.candidobugarin.table3;

/**
 * Created by candidobugarin on 03/09/17.
 */

public class ListSec {
    public String nome;
    public Double lat;
    public Double lon;
}